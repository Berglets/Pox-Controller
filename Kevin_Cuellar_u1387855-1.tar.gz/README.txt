Before you run anything, make sure to elevate privileges with "sudo bash". Now you can run the 
script with any options. There are options for each step outlined in the assignment description.
Or just run with --all for the complete setup to occur, then you can run with -p north or -p south
to change the route of traffic. 

Video link:
https://drive.google.com/file/d/1oHpcslEEKwtr-fQ8Mv-D5OUxa11BVgUY/view?usp=drive_link